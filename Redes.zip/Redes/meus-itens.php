<?php
session_start();
require_once 'Connection_db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = intval($_SESSION['user_id']);

$query = "SELECT * FROM itens WHERE user_id = ? ORDER BY id DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="pt">

<head>
  <meta charset="UTF-8">
  <title>Meus Itens</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <header>
    <h1>Troca Escolar</h1>
    <nav>
      <a href="index.php">Itens</a>
      <a href="logout.php">Logout</a>
    </nav>
  </header>

  <main style="padding-top: 8rem;">
    <h2 style="text-align:center;">Os Meus Itens</h2>

    <div class="filtros">
      <a href="adicionar-item.php" class="btn-adicionar" style="margin-left:auto;">+ Adicionar</a>
    </div>

    <div class="item-list">
    <?php
while ($item = mysqli_fetch_assoc($result)) {
    $isMe = ($item['user_id'] == $user_id);

    echo '<div class="item" style="' . ($isMe ? 'border: 2px solid green;' : 'border: 1px solid #ddd;') . ' padding: 15px; margin-bottom: 15px; border-radius: 8px;">';
    echo '<img src="' . htmlspecialchars($item['Imagem']) . '" alt="Item" style="max-width:100%; height:180px; object-fit: cover; border-radius: 6px;">';
    echo '<div class="item-content" style="margin-top: 10px;">';
    echo '<h3>' . htmlspecialchars($item['Nome']) . '</h3>';
    echo '<p>' . htmlspecialchars($item['Descricao']) . '</p>';

    echo '<div style="display: flex; gap: 10px; align-items: center;">';
    echo '<a href="detalhes-item.php?id=' . $item['Id'] . '" class="btn-adicionar" style="padding: 8px 12px; background-color: #007bff; color: white; text-decoration: none; border-radius: 5px; display: inline-block;">Ver detalhes</a>';

    if ($isMe) {
        echo '<form action="delete.php" method="GET" onsubmit="return confirm(\'Tens a certeza que queres apagar este item?\')">';
        echo '<input type="hidden" name="id" value="' . $item['Id'] . '">';
        echo '<button type="submit" style="background-color:#dc3545; color:#fff; border:none; padding: 8px 12px; border-radius:5px; cursor:pointer;">🗑️ Deletar</button>';
        echo '</form>';
    }
    echo '</div>'; 

    echo '</div></div>';
}
?>


    </div>
  </main>

  <footer>
    <p>&copy; Gabi, Mille e FiFi gay.</p>
  </footer>
</body>
</html>
