<?php
session_start();
if (!isset($_SESSION['user_id'])) {
  header("Location: login.php");
  exit;
}

require 'Connection_db.php';
$user_id = $_SESSION['user_id'];

$mensagem = '';
if (isset($_GET['msg'])) {
  if ($_GET['msg'] == 'sucesso') {
    $mensagem = '<div class="alert sucesso">Proposta enviada com sucesso!</div>';
  } else if ($_GET['msg'] == 'erro') {
    $mensagem = '<div class="alert erro">Erro ao enviar proposta. Tente novamente.</div>';
  }
}

$categoria = $_GET['categoria'] ?? '';
$pesquisa = $_GET['pesquisa'] ?? '';

$sql = "SELECT itens.*, login.email FROM itens JOIN login ON itens.user_id = login.id WHERE 1=1";

$params = [];
$types = "";

if ($categoria !== '') {
  $sql .= " AND categoria = ?";
  $params[] = $categoria;
  $types .= "s";
}

if ($pesquisa !== '') {
  $sql .= " AND itens.Nome LIKE ?";
  $params[] = "%" . $pesquisa . "%";
  $types .= "s";
}


$sql .= " ORDER BY itens.id DESC";

$stmt = $conn->prepare($sql);

if (!empty($params)) {
  $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="pt">

<head>
  <meta charset="UTF-8">
  <title>Troca Escolar - Início</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <header>
    <h1>Troca Escolar</h1>
    <nav>
      <a href="index.php">Itens</a>
      <a href="propostas.php">Propostas</a>
      <a href="meus-itens.php">Meus itens</a>
      <a href="logout.php">Logout</a>
    </nav>
  </header>

  <section class="hero">
    <h2>Troca, Partilha, Reutiliza</h2>
    <p>Encontra ou oferece materiais escolares em bom estado.</p>
  </section>

  <main>
    <?php if ($mensagem) echo $mensagem; ?>

    <div class="filtros">
      <form method="GET" action="" style="display:flex; gap:10px; align-items:center; flex-grow:1;">
        <select name="categoria" onchange="this.form.submit()">
          <option value="" <?php if ($categoria == '') echo 'selected'; ?>>Todas as categorias</option>
          <option value="Livros" <?php if ($categoria == 'Livros') echo 'selected'; ?>>Livros</option>
          <option value="Roupas" <?php if ($categoria == 'Roupas') echo 'selected'; ?>>Roupas</option>
          <option value="Brinquedos" <?php if ($categoria == 'Brinquedos') echo 'selected'; ?>>Brinquedos</option>
        </select>

        <input
          type="text"
          name="pesquisa"
          placeholder="Pesquisar por nome..."
          value="<?php echo htmlspecialchars($pesquisa, ENT_QUOTES); ?>"
          onkeypress="if(event.key === 'Enter') this.form.submit();"
          style="flex-grow: 1;"
        >

        <button type="submit" class="btn-adicionar">Filtrar</button>
      </form>

    </div>

    <div class="item-list">
      <?php
      while ($item = $result->fetch_assoc()) {
        $isMe = ($item['user_id'] == $user_id);

        echo '<div class="item" style="' . ($isMe ? 'border: 2px solid green;' : 'border: 1px solid #ddd;') . ' padding: 15px; margin-bottom: 15px; border-radius: 8px;">';
        echo '<img src="' . htmlspecialchars($item['Imagem']) . '" alt="Item" style="max-width:100%; height:180px; object-fit: cover; border-radius: 6px;">';

        echo '<div class="item-content" style="margin-top: 10px;">';
        echo '<h3>' . htmlspecialchars($item['Nome']) . ' - ID: ' . $item['Id'] . '</h3>';
        echo '<p>' . htmlspecialchars($item['Descricao']) . '</p>';

        echo '<div style="display: flex; flex-wrap: wrap; gap: 10px; align-items: center; margin-top: 10px;">';

        echo '<a href="detalhes-item.php?id=' . $item['Id'] . '" class="btn-adicionar" style="padding: 8px 12px; background-color: #007bff; color: white; text-decoration: none; border-radius: 5px; display: inline-block;">Ver detalhes</a>';

        if (!$isMe) {
          echo '<form method="POST" action="propor_troca.php" style="display: flex; gap: 8px; align-items: center;">';
          echo '<input type="hidden" name="item_desejado_id" value="' . $item['Id'] . '">';

          echo '<select name="item_oferecido_id" required style="padding: 6px; border-radius: 4px; border: 1px solid #ccc;">';

          $user_itens_query = "SELECT id, Nome FROM itens WHERE user_id = ?";
          $stmt2 = $conn->prepare($user_itens_query);
          $stmt2->bind_param("i", $user_id);
          $stmt2->execute();
          $user_itens = $stmt2->get_result();

          while ($user_item = $user_itens->fetch_assoc()) {
            $display_text = htmlspecialchars($user_item['Nome']) . ' (ID: ' . $user_item['id'] . ')';
            echo '<option value="' . $user_item['id'] . '">' . $display_text . '</option>';
          }
          echo '</select>';

          echo '<button type="submit" style="padding: 8px 12px; background-color: #28a745; color: white; border: none; border-radius: 5px; cursor: pointer;">Propor Troca</button>';
          echo '</form>';
        }

        echo '</div>';
        echo '</div></div>';
      }
      ?>
    </div>
  </main>

  <footer>
    <p>&copy; Gabi, Mille e FiFi gay.</p>
  </footer>
</body>

</html>
