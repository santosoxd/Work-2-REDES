<?php
require_once("Connection_db.php");
session_start();

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $email = $_POST['Email'];
    $senha = md5($_POST['Senha']);

    $query = "SELECT * FROM login WHERE Email = ? AND Senha = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $email, vars: $senha);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        $_SESSION['user_id'] = $user['Id']; 
        header('Location: index.php');
        exit;
    } else {
        $error = "Email ou senha incorretos.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title>Login</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>Troca Escolar</h1>
    <nav><a href="registo.php">Registar</a></nav>
  </header>

  <main style="padding-top: 8rem;">
    <h2 style="text-align:center; margin-bottom: 1rem;">Login</h2>
    <form method="POST" style="max-width: 400px; margin: auto;">
      <input type="email" placeholder="Email" name="Email" required style="margin-bottom: 1rem; width: 100%; padding: 0.75rem;">
      <input type="password" placeholder="Senha" name="Senha" required style="margin-bottom: 1rem; width: 100%; padding: 0.75rem;">
      <button type="submit" style="width: 100%; padding: 0.75rem; background-color: #ff2e88; color: white; border: none;">Entrar</button>
    </form>
    <?php if (isset($error)) echo '<p style="color:red; text-align:center;">'.$error.'</p>'; ?>
  </main>

  <footer>
    <p>&copy; Gabi, Mille e FiFi gay.</p>
  </footer>
</body>
</html>