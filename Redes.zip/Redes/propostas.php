<?php
session_start();
require_once "Connection_db.php";

$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $troca_id = $_POST['troca_id'];
    $acao = $_POST['acao']; 

    if ($acao === 'aceite') {
        $stmt = $conn->prepare("SELECT item_oferecido_id, item_desejado_id, user_oferece_id, user_recebe_id FROM trocas WHERE id = ? AND user_recebe_id = ?");
        $stmt->bind_param("ii", $troca_id, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($troca = $result->fetch_assoc()) {
            $conn->begin_transaction();

            try {
                $stmt1 = $conn->prepare("UPDATE itens SET user_id = ? WHERE id = ?");
                $stmt1->bind_param("ii", $troca['user_recebe_id'], $troca['item_oferecido_id']);
                $stmt1->execute();

                $stmt2 = $conn->prepare("UPDATE itens SET user_id = ? WHERE id = ?");
                $stmt2->bind_param("ii", $troca['user_oferece_id'], $troca['item_desejado_id']);
                $stmt2->execute();

                $stmt3 = $conn->prepare("UPDATE trocas SET estado = 'aceite', data_resposta = NOW() WHERE id = ?");
                $stmt3->bind_param("i", $troca_id);
                $stmt3->execute();

                $conn->commit();
                $mensagem = "Troca aceite com sucesso!";
            } catch (Exception $e) {
                $conn->rollback();
                $mensagem = "Erro ao processar troca: " . $e->getMessage();
            }
        }
    } elseif ($acao === 'recusado') {
        $stmt = $conn->prepare("UPDATE trocas SET estado = 'recusado', data_resposta = NOW() WHERE id = ? AND user_recebe_id = ?");
        $stmt->bind_param("ii", $troca_id, $user_id);
        $stmt->execute();
        $mensagem = "Troca recusada.";
    }
}

$stmt = $conn->prepare("
    SELECT t.id, i1.id AS item_oferecido_id, i1.Nome AS item_oferecido, i2.id AS item_desejado_id, i2.Nome AS item_desejado, u1.Email AS oferece_email
    FROM trocas t
    JOIN itens i1 ON t.item_oferecido_id = i1.id
    JOIN itens i2 ON t.item_desejado_id = i2.id
    JOIN login u1 ON t.user_oferece_id = u1.Id
    WHERE t.user_recebe_id = ? AND t.estado = 'pendente'
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$propostas = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Propostas de Troca</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
    <h1>Propostas de Troca</h1>
    <nav>
      <a href="index.php">Itens</a>
      <a href="logout.php">Logout</a>
    </nav>
</header>

<main style="padding-top: 6rem; max-width: 800px; margin: auto;">
    <?php if (isset($mensagem)) echo '<p style="color:green;">' . htmlspecialchars($mensagem) . '</p>'; ?>

    <?php if ($propostas->num_rows == 0): ?>
        <p>Não tens propostas pendentes.</p>
    <?php else: ?>
        <?php while ($p = $propostas->fetch_assoc()): ?>
            <div class="item" style="border:1px solid #ddd; padding:15px; margin-bottom:15px; border-radius:8px;">
                <p><strong>Utilizador:</strong> <?php echo htmlspecialchars($p['oferece_email']); ?></p>
                <p><strong>Item que te oferecem:</strong> <?php echo htmlspecialchars($p['item_oferecido']); ?> (ID: <?php echo $p['item_oferecido_id']; ?>)</p>
                <p><strong>Item que querem trocar contigo:</strong> <?php echo htmlspecialchars($p['item_desejado']); ?> (ID: <?php echo $p['item_desejado_id']; ?>)</p>

                <form method="POST" style="display:inline-block;">
                    <input type="hidden" name="troca_id" value="<?php echo $p['id']; ?>">
                    <button type="submit" name="acao" value="aceite" style="background-color:green; color:white; padding:8px 16px; border:none; border-radius:5px; margin-right:10px;">Aceitar</button>
                    <button type="submit" name="acao" value="recusado" style="background-color:red; color:white; padding:8px 16px; border:none; border-radius:5px;">Recusar</button>
                </form>
            </div>
        <?php endwhile; ?>
    <?php endif; ?>
</main>
</body>
</html>
