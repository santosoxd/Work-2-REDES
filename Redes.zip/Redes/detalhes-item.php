<?php
session_start();
if (!isset($_SESSION['user_id'])) {
  header("Location: login.php");
  exit;
}

require 'Connection_db.php';

// Verifica se o ID foi enviado por POST
if (!isset($_POST['item_id']) || !is_numeric($_POST['item_id'])) {
  echo "ID inválido.";
  exit;
}

$id = (int)$_POST['item_id'];

// Buscar detalhes do item
$sql = "
  SELECT itens.*, login.email 
  FROM itens 
  JOIN login ON itens.user_id = login.id 
  WHERE itens.id = ?
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
  echo "Item não encontrado.";
  exit;
}

$item = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title>Detalhes do Item</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .item-detalhe {
      max-width: 600px;
      margin: 30px auto;
      border: 1px solid #ccc;
      border-radius: 8px;
      padding: 20px;
      background: #f9f9f9;
    }

    .item-detalhe img {
      max-width: 100%;
      height: 250px;
      object-fit: cover;
      border-radius: 8px;
      margin-bottom: 15px;
    }

    .item-detalhe h2 {
      margin-top: 0;
    }

    .btn-voltar {
      display: inline-block;
      margin-top: 20px;
      padding: 10px 15px;
      background: #007bff;
      color: white;
      text-decoration: none;
      border-radius: 5px;
    }

    .btn-voltar:hover {
      background: #0056b3;
    }
  </style>
</head>
<body>
  <header>
    <h1>Detalhes do Item</h1>
    <nav>
      <a href="index.php">Voltar</a>
      <a href="propostas.php">Propostas</a>
      <a href="logout.php">Logout</a>
    </nav>
  </header>

  <main>
    <div class="item-detalhe">
      <img src="<?= htmlspecialchars($item['Imagem']) ?>" alt="Imagem do item">
      <h2><?= htmlspecialchars($item['Nome']) ?></h2>
      <p><strong>Descrição:</strong> <?= htmlspecialchars($item['Descricao']) ?></p>
      <p><strong>Categoria:</strong> <?= htmlspecialchars($item['Categoria']) ?></p>
      <p><strong>Email do Dono:</strong> <?= htmlspecialchars($item['email']) ?></p>

      <a href="index.php" class="btn-voltar">← Voltar aos Itens</a>
    </div>
  </main>
</body>
</html>

