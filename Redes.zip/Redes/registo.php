<!DOCTYPE html>
<html lang="pt">

<head>
  <meta charset="UTF-8">
  <title>Registo</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <header>
    <h1>Troca Escolar</h1>
    <nav>
      <a href="index.html">Itens</a>
      <a href="login.php">Login</a>
    </nav>
  </header>

  <main style="padding-top: 8rem;">
    <h2 style="text-align:center; margin-bottom: 1rem;">Criar Conta</h2>
    <form id="formRegisto" style="max-width: 400px; margin: auto;" method="POST">
      <input type="text" placeholder="Nome" name="Nome" required
        style="margin-bottom: 1rem; width: 100%; padding: 0.75rem;">
      <input type="email" placeholder="Email" name="Email" required
        style="margin-bottom: 1rem; width: 100%; padding: 0.75rem;">
      <input type="password" placeholder="Senha" name="Senha" required
        style="margin-bottom: 1rem; width: 100%; padding: 0.75rem;">
      <button type="submit"
        style="width: 100%; padding: 0.75rem; background-color: #ff2e88; color: white; border: none;">Registar</button>

      <?php
      if (!empty($mensagem)) {
        echo "<p>$mensagem</p>";
      }
      ?>
    </form>
  </main>

  <footer>
    <p>&copy; Gabi, Mille e FiFi gay.</p>
  </footer>
</body>

</html>
<?php
include "Connection_db.php";
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$mensagem = "";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
  $nome = $_POST['Nome'];
  $email = $_POST['Email'];
  $senha = md5($_POST['Senha']); 
  $query = "INSERT INTO login (Nome, Email, Senha) VALUES ('$nome', '$email', '$senha')";

  try {
    mysqli_query($conn, $query);
    header("Location: login.php");
    exit;
  } catch (mysqli_sql_exception $e) {
    if ($e->getCode() == 1062) {
      $mensagem = "⚠ Este email já está registado.";
      header('Location: index.php');
    } else {
      $mensagem = "❌ Erro ao registar utilizador.";
    }
  }
}
?>