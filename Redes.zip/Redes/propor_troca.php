<?php
session_start();
require 'Connection_db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

if (!$conn) {
    die("Erro de conexão: " . mysqli_connect_error());
}

if (isset($_POST['item_desejado_id'], $_POST['item_oferecido_id'])) {
    $item_desejado_id = intval($_POST['item_desejado_id']);
    $item_oferecido_id = intval($_POST['item_oferecido_id']);

    $queryCheck = "SELECT id FROM itens WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($queryCheck);
    $stmt->bind_param("ii", $item_oferecido_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        die("Este item não te pertence!");
    }
    $stmt->close();

    $queryDono = "SELECT user_id FROM itens WHERE id = ?";
    $stmtDono = $conn->prepare($queryDono);
    $stmtDono->bind_param("i", $item_desejado_id);
    $stmtDono->execute();
    $resultDono = $stmtDono->get_result();
    $rowDono = $resultDono->fetch_assoc();
    $user_recebe_id = $rowDono['user_id'];
    $stmtDono->close();

    $insertQuery = "INSERT INTO trocas (user_oferece_id, user_recebe_id, item_desejado_id, item_oferecido_id, estado, data_proposta) 
                    VALUES (?, ?, ?, ?, 'pendente', NOW())";
    $stmtInsert = $conn->prepare($insertQuery);
    $stmtInsert->bind_param("iiii", $user_id, $user_recebe_id, $item_desejado_id, $item_oferecido_id);

    if ($stmtInsert->execute()) {
        header("Location: index.php?msg=sucesso");
        exit;
    } else {
        die("Erro ao enviar proposta: " . $stmtInsert->error);
    }

} else {
    die("Dados inválidos.");
}
?>
