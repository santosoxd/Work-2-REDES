<?php
#connection
$host = "localhost";
$usuario = "root";
$senha = "";
$banco = "projeto_breno";

$conn = mysqli_connect($host, $usuario, $senha, $banco);
if (!$conn) {
    die("conexão falhou: " . mysqli_connect_error());
}
?>