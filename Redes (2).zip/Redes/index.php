<?php
session_start();
if (!isset($_SESSION['user_id'])) {
  header("Location: login.php");
}
?>

<!DOCTYPE html>
<html lang="pt">

<head>
  <meta charset="UTF-8">
  <title>Troca Escolar - Início</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <header>
    <h1>Troca Escolar</h1>
    <nav>
      <a href="meus-itens.php">Meu Perfil</a>
      <?php
      if (!isset($_SESSION['user_id'])) {
        ?>
        <a href="login.php">Login</a>
        <?php

      } else {
        ?>
        <a href="logout.php">logout</a>
        <?php
      }
      ?>

    </nav>
  </header>

  <section class="hero">
    <h2>Troca, Partilha, Reutiliza</h2>
    <p>Encontra ou oferece materiais escolares em bom estado.</p>
  </section>

  <main>

    <!-- Filtros -->
    <div class="filtros">
      <select>
        <option>Todas as categorias</option>
        <option>Livros</option>
        <option>Roupas</option>
        <option>Brinquedos</option>
      </select>
      <input type="text" placeholder="Pesquisar por nome...">
      <a href="adicionar-item.php" class="btn-adicionar" id="btnAdicionar" style="display: none;">+ Adicionar</a>
    </div>


    <!-- Lista de Itens -->
    <div class="item-list">
      <div class="item">
        <img src="a.png" alt="Item 1">
        <div class="item-content">
          <h3>Livro de Matemática</h3>
          <p>Bom estado, 9º ano.</p>
          <a href="detalhes-item.html">Ver detalhes</a>
        </div>
      </div>
    </div>
  </main>

  <footer>
    <p>&copy; Gabi, Mille e FiFi gay.</p>
  </footer>
</body>

</html>

<script>
  // Suponha que você armazene "usuarioLogado" como true no localStorage após login
  const usuarioLogado = localStorage.getItem("usuarioLogado");

  if (usuarioLogado === "true") {
    document.getElementById("btnAdicionar").style.display = "inline-block";
  }
</script>