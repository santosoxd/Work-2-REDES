<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title>Adicionar Item</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
    <h1>Troca Escolar</h1>
    <nav>
      <a href="index.php">Home</a>
      <a href="meus-itens.php">Meu Perfil</a>
      <?php
      if (!isset($_SESSION['user_id'])) {
        ?>
        <a href="login.php">Login</a>
        <?php

      } else {
        ?>
        <a href="logout.php">logout</a>
        <?php
      }
      ?>
    </nav>
  </header>

  <main style="padding-top: 6rem; max-width: 700px; margin: auto;">
    <h2 style="text-align: center; color: #ff6faf; margin-bottom: 2rem;">Adicionar Novo Item</h2>

    <form method="POST" enctype="multipart/form-data" class="form-add-item">
      <label for="nome">Nome do Item</label>
      <input type="text" id="nome" name="nome" required>

      <label for="descricao">Descrição</label>
      <textarea id="descricao" name="descricao" rows="4" required></textarea>

      <label for="categoria">Categoria</label>
      <select id="categoria" name="categoria" required>
        <option value="">Escolher categoria</option>
        <option value="livros">Livros</option>
        <option value="roupas">Roupas</option>
        <option value="brinquedos">Brinquedos</option>
        <option value="outros">Outros</option>
      </select>

      <label for="foto">Imagem do Item</label>
      <input type="file" id="foto" name="foto" accept="image/*">

      <button type="submit">Adicionar Item</button>
    </form>
  </main>

  <footer>
    <p>&copy; Gabi, Mille e FiFi gay.</p>
  </footer>
</body>
</html>

<?php
require 'Connection_db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $descricao = $_POST['descricao'];
    $categoria = $_POST['categoria'];

    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === 0) {
        $foto_nome = basename($_FILES['foto']['name']); 
        $foto_tmp = $_FILES['foto']['tmp_name'];
        $destino = "uploads/" . uniqid() . "_" . $foto_nome; 

        if (move_uploaded_file($foto_tmp, $destino)) {
            $stmt = $conn->prepare("INSERT INTO itens (Nome, Descricao, Categoria, Imagem) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $nome, $descricao, $categoria, $destino);

            if ($stmt->execute()) {
                echo "Item adicionado com sucesso!";
                header("Location: index.php");
                exit;
            } else {
                echo "Erro ao inserir: " . $stmt->error;
            }

            $stmt->close();
        } else {
            echo "Erro ao mover o ficheiro.";
        }
    } else {
        echo "Erro ao enviar a imagem.";
    }
}
?>


