<?php
session_start();
require_once "Connection_db.php";
?>

<!DOCTYPE html>
<html lang="pt">

<head>
  <meta charset="UTF-8">
  <title>Meus Itens</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <header>
    <h1>Troca Escolar</h1>
    <nav>
      <a href="index.php">Itens</a>
      <a href="login.php">Logout</a>
    </nav>
  </header>


  <main style="padding-top: 8rem;">
    <h2 style="text-align:center;">Os Meus Itens</h2>
    <main>
      <div class="filtros">

        <a href="adicionar-item.php" class="btn-adicionar" id="btnAdicionar" style="text-align: right">+ Adicionar</a>
      </div>
      <div class="item-list">
        <?php
        $query = "SELECT * FROM itens ORDER BY id DESC";
        $result = mysqli_query($conn, $query);

        while ($item = mysqli_fetch_assoc($result)) {
          echo '<div class="item">';
          echo '<img src="' . $item['Imagem'] . '" alt="Item">';
          echo '<div class="item-content">';
          echo '<h3>' . htmlspecialchars($item['Nome']) . '</h3>';
          echo '<p>' . htmlspecialchars(string: $item['Descricao']) . '</p>';
        }
        ?>
        <?php
        echo "<form action='delete.php' method='GET' onsubmit='return confirm(\"Tens a certeza que queres apagar este item?\")'>";
        echo "<input type='hidden' name='id' value='" . $row['id'] . "'>";
        echo "<button type='submit'>🗑️ Deletar</button>";
        ?>
      </div>
    </main>
    <footer>
      <p>&copy; Gabi, Mille e FiFi gay.</p>
    </footer>
</body>
</html>
<?php
require 'Connection_db.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Prepara e executa a query segura
    $stmt = $conn->prepare("DELETE FROM itens WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "Item deletado com sucesso.";
        header("Location: index.php");
        exit;
    } else {
        echo "Erro ao deletar: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "ID não fornecido.";
}
?>