<?php
  require_once ("Connection_db.php");
?>

<!DOCTYPE html>
<html lang="pt">

<head>
  <meta charset="UTF-8">
  <title>Registo</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <header>
    <h1>Troca Escolar</h1>
    <nav>
      <a href="index.html">Itens</a>
      <a href="login.php">Login</a>
    </nav>
  </header>

  <main style="padding-top: 8rem;">
    <h2 style="text-align:center; margin-bottom: 1rem;">Criar Conta</h2>
    <form id="formRegisto" style="max-width: 400px; margin: auto;" method="POST">
      <input type="text" placeholder="Nome" name="Nome" required style="margin-bottom: 1rem; width: 100%; padding: 0.75rem;">
      <input type="email" placeholder="Email" name="Email" required style="margin-bottom: 1rem; width: 100%; padding: 0.75rem;">
      <input type="password" placeholder="Senha" name="Senha" required style="margin-bottom: 1rem; width: 100%; padding: 0.75rem;">
      <button type="submit"
        style="width: 100%; padding: 0.75rem; background-color: #ff2e88; color: white; border: none;">Registar</button>
    </form>
  </main>
  <footer>
    <p>&copy; Gabi, Mille e FiFi gay.</p>
  </footer>
</body>

</html>

<?php
if($_SERVER['REQUEST_METHOD' ] == "POST"){
  $nome = $_POST['Nome'];
  $email = $_POST['Email'];
  $senha = md5($_POST['Senha']);
  $query = "INSERT INTO login (Nome, Email, Senha) VALUES ('$nome', '$email', '$senha')";
  if (mysqli_query($conn, $query)) {
    echo "Nome e Curso inserido com sucesso <br><br>";
    header('Location: index.php');
  } else {
    echo "Erro ao inserir Nome ou Curso" . mysqli_error($conn);
  }
}
?>